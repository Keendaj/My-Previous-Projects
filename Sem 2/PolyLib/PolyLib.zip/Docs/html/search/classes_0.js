var searchData=
[
  ['poly_5ft_0',['poly_t',['../structpoly__t.html',1,'']]]
];
